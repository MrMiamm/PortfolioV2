for i in img/???.svg
do
    echo "Convertion des logos"
    r="${i/svg/png}"
    convert -resize 200x200 "$i" "$r"
    convert -crop  200x185+0+0 "$i" "$r"
    convert -resize 200x200 "$i" "$r"
    convert "$r" -colorspace Gray "$r"
done

