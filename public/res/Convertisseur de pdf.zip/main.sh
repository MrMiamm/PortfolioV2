#!/bin/bash
./qrcode_creator.sh
./Logo.sh
for file in `ls ./textes/*.txt`; do
    nom="${file/.txt/}"
    nom="${nom/.\/textes\//}"
    echo $nom
    cd ./textes
    php convertion_texte_dat.php $nom
    php datToHtml.php  
    cd ..
    code=$(cat regions.conf | egrep $nom | cut -d ',' -f 1)
    echo $code
    ./html_to_pdf_converter.sh $code
    mv *.pdf ./res
done