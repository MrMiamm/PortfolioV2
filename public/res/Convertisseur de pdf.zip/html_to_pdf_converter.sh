#!/bin/bash
if [ "$1" != "" ]
then
    cp ./$1.html /Docker/$USER/
    docker run --rm -ti -v /Docker/$USER:/work sae103-html2pdf "html2pdf $1.html $1.pdf"
    cp /Docker/$USER/$1.pdf .
else
    echo "Erreur : Veuillez mettre un paramètre"
fi