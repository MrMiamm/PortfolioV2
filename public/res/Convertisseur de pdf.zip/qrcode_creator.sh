#!/bin/bash
echo "Creation des qrcodes"
while IFS= read -r line; do
    nom=$(echo $line | cut -d ',' -f 1)
    echo https://bigbrain.biz/$nom | docker run --rm -i sae103-qrcode qrencode -l L -o - > img/qrcode$nom
done < "regions.conf"