<?php 
    $code = substr(strtoupper(file("texte.dat")[0]),0,6);
    $nomFic = "$code.html";
    file_put_contents($nomFic,"<!DOCTYPE html>");
    file_put_contents($nomFic,"<html lang=\"fr\"><head>
    <meta charset=\"UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <link rel=\"stylesheet\" href=\"sample.css\">
    </head>
    <body>
        <main>
            <section>
                <div class=\"couverture\">",FILE_APPEND);

    $lines = file("regions.conf");
    for ($i=1; $i < count($lines) ; $i++) {
        if (substr($lines[$i],0,6) == $code) {
            $line = explode(',',$lines[$i]);
            file_put_contents($nomFic,"<h1>$line[1]<br>",FILE_APPEND);
            file_put_contents($nomFic,"Population: $line[2]<br>",FILE_APPEND);
            file_put_contents($nomFic,"Superficie: $line[3]<br>",FILE_APPEND);
            file_put_contents($nomFic,"Nbre de départements: $line[4]</h1>",FILE_APPEND);
            file_put_contents($nomFic,"<img src=\"img/$line[0].png\">",FILE_APPEND);
        }
    }
    file_put_contents($nomFic,"</div>",FILE_APPEND);
    
    $lines = file("texte.dat");
    $bottom = $lines[count($lines)-1];
    $bottom = substr($bottom,4);
    file_put_contents($nomFic,$bottom,FILE_APPEND);

    file_put_contents($nomFic,"</section><section>",FILE_APPEND);
    
    for ($i=1; $i < count($lines) ; $i++) { 
        file_put_contents($nomFic,$lines[$i],FILE_APPEND);
    }

    $tableau = file("tableau.dat");
    for ($i=0; $i < count($tableau); $i++) { 
        file_put_contents($nomFic,$tableau[$i],FILE_APPEND);
    }

    file_put_contents($nomFic,"</section><section><div class=\"top\"><h1>Nos meilleurs vendeurs du trimestre</h1></div>
    <div class=\"contenu\">",FILE_APPEND);

    $vendeurs = file("comm.dat");
    for ($i=0; $i < count($vendeurs); $i++){ 
        file_put_contents($nomFic,$vendeurs[$i],FILE_APPEND);
    }
    file_put_contents($nomFic,"</div>",FILE_APPEND);
    file_put_contents($nomFic,$bottom,FILE_APPEND);

    file_put_contents($nomFic,"</section>
    <section>
        <div class=\"top\"><h1>Ressources</h1></div>
        <div class=\"contenu\">
            <figure>
                <img src=\"img/qrcode",FILE_APPEND);

    
    file_put_contents($nomFic,$code,FILE_APPEND);
    file_put_contents($nomFic,".png\"><figcaption><a href=\"https://bigbrain/",FILE_APPEND);
    file_put_contents($nomFic,$code,FILE_APPEND);
    file_put_contents($nomFic,"\">Site de la société</a></figcaption></figure></div>",FILE_APPEND);
    file_put_contents($nomFic,$bottom,FILE_APPEND);
    file_put_contents($nomFic,"</section>
                            </main>
                        </body>
                        </html>",FILE_APPEND);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sample.css">
</head>
<body>
    <main>
        <section>
            <div class="couverture">
                <?php 
                    $code = substr(strtoupper(file("texte.dat")[0]),0,6);
                    $lines = file("regions.conf");
                    for ($i=1; $i < count($lines) ; $i++) {
                        if (substr($lines[$i],0,6) == $code) {
                            $line = explode(',',$lines[$i]);
                            echo "<h1>$line[1]<br>";
                            echo "Population: $line[2]<br>";
                            echo "Superficie: $line[3]<br>";
                            echo "Nbre de départements: $line[4]</h1>";
                            echo "<img src=\"img/$line[0].png\">";
                        }
                    }
                ?>
            </div>
            <?php 
                $lines = file("texte.dat");
                $bottom = $lines[count($lines)-1];
                $bottom = substr($bottom,4);
                echo $bottom;
            ?>
        </section>
        <section>
            <?php
                for ($i=1; $i < count($lines) ; $i++) { 
                    echo $lines[$i];
                }
                include "tableau.dat"
            ?>
        </section>
        <section>
            <div class="top"><h1>Nos meilleurs vendeurs du trimestre</h1></div>
            <div class="contenu">
                <?php include "comm.dat"; ?>
            </div>
            <?php echo $bottom ?>
        </section>
        <section>
            <div class="top"><h1>Ressources</h1></div>
            <div class="contenu">
                <figure>
                    <img src="img/qrcode.png">
                    <figcaption><a href="https://bigbrain.biz/29200">Site de la société</a></figcaption>
                </figure>
            </div>
            <?php echo $bottom ?>
        </section>
    </main>
</body>
</html>