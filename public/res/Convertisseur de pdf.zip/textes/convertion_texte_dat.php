#!/usr/bin/php
<?php
    $tabarg = ['0'];    
    $lines=file("$argv[1].txt");
    foreach($lines as $key => $value) {
        if (preg_match("/MEILLEURS:/i",$value)) {
            $tab=$value;
        }
    }
    $tab = explode(",", $tab);
    $tab[0]=substr($tab[0], 10);
    foreach ($tab as $num => $price) {
        $tabarg[$num] = (int)(preg_replace("/[^0-9]/", "", $price ));
    }
    sort($tabarg, SORT_NUMERIC);
    foreach ($tab as $num => $value) {
        $current=(int)(preg_replace("/[^0-9]/", "", $value ));
        if(($current==$tabarg[count($tabarg)-1])){
            $CA[0]="$current 000";
            $ID[0]=substr($value, 0, 3);
            $NO[0]=substr($value, 4);
            $NO[0]=substr($NO[0], 0, -7);
            $ID[0] = strtolower($ID[0]);
        } else if ($current==$tabarg[count($tabarg)-2]) {
            $CA[1]="$current 000";
            $ID[1]=substr($value, 0, 3);
            $NO[1]=substr($value, 4);
            $NO[1]=substr($NO[1], 0, -7);
            $ID[1] = strtolower($ID[1]);
        } else if ($current==$tabarg[count($tabarg)-3]) {
            $CA[2]="$current 000";
            $ID[2]=substr($value, 0, 3);
            $NO[2]=substr($value, 4);
            $NO[2]=substr($NO[2], 0, -7);
            $ID[2] = strtolower($ID[2]);
        }
        
        else {
            array_splice($tab, $num, 1);
        }
    }


    file_put_contents("comm.dat",
    "<figure><img src=\"img/$ID[0].svg\">\n<figcaption>Nom: $NO[0] - CA: $CA[0]</figcaption></figure>\n<figure><img src=\"img/$ID[1].svg\">\n<figcaption>Nom: $NO[1] - CA: $CA[1]</figcaption></figure>\n<figure><img src=\"img/$ID[2].svg\"><figcaption>Nom: $NO[2] - CA: $CA[2]</figcaption></figure>\n");

    $annee =  date("Y");
    $mois = date("n");
    $date = date("d-m-Y H:i");
    if ($mois <= 3) {
        $trimestre = 1;
    } elseif ($mois <= 6){
        $trimestre = 2;
    } elseif ($mois <= 9){
        $trimestre = 3;
    } else {
        $trimestre = 4;
    }

    $capture = FALSE;
    for ($i=0; $i < count($lines); $i++) {
        if (preg_match('/code=/i',$lines[$i])) {
            $trans = substr($lines[$i],5);
            file_put_contents('texte.dat',"$trans");
            file_put_contents("texte.dat","<div class=\"top\"><h1>Résultats trimestriels $trimestre $annee</h1></div>\n",FILE_APPEND);
        } elseif (preg_match('/sous_titre=/i',$lines[$i])) {
            $trans = substr($lines[$i],11);
            file_put_contents('texte.dat',"<h2>$trans</h2>",FILE_APPEND);
        } elseif (preg_match('/titre=/i',$lines[$i])) {
            $trans = substr($lines[$i],6);
            file_put_contents('texte.dat',"<h2>$trans</h2>",FILE_APPEND);
        } elseif (preg_match('/d.but_texte/i',$lines[$i])) {
            $capture = TRUE;
        } elseif (preg_match('/fin_texte/i',$lines[$i])) {
            $capture = FALSE;
        } elseif ($capture) {
            $trans = $lines[$i];
            $trans = str_replace('\n',' ',$trans);
            file_put_contents('texte.dat',"<p>$trans</p>",FILE_APPEND);
        }
    }
    file_put_contents("texte.dat","<div class=\"bottom\"><p>$date</p></div>", FILE_APPEND);


    $dedans = FALSE;
    $fic = fopen("tableau.dat", "w");
    fwrite($fic,"<table><thead><tr><th>Nom de Produit</th><th>Ventes du trimestre  </th><th>Chiffre d'affaires du trimestre  </th><th>Ventes du même trimestre année précédente  </th><th>Chiffre d'affaires trimestre précédent</th>  <th>Pourcentage augmentaton du chiffre d'affaires</th></tr></thead><tbody>");
    for ($i = 0; $i < count($lines); $i++) {
        if (($dedans == TRUE)&& !preg_match('/FIN_STATS/i', $lines[$i])){
            $data = explode(",", $lines[$i]);
            fwrite($fic,"<tr>");
            for ($j = 0; $j < count($data);$j++){
                fwrite($fic,"<td>");
                fwrite($fic,$data[$j]);
                fwrite($fic,"</td>");
            }
            $pourcent =((intval($data[4]) - intval($data[2]))/intval($data[2]))*100;
            if($pourcent < 0){
                $pourcent = $pourcent * -1;
                fwrite($fic,"<td><b class=\"CAneg\">");
                fwrite($fic,number_format((float)$pourcent, 2, '.', ''));
                fwrite($fic,"%");
                fwrite($fic,"</b></td>");
            }else {
                fwrite($fic,"<td><b class=\"CApos\">");
                fwrite($fic,number_format((float)$pourcent, 2, '.', ''));
                fwrite($fic,"%");
                fwrite($fic,"</b></td>");
            }
            fwrite($fic,"</tr>");
        }
        if (preg_match('/DEBUT_STATS/i', $lines[$i])) {
            $dedans = TRUE;
            $trouve = TRUE;
        }
        if (preg_match('/FIN_STATS/i', $lines[$i])) {
            $dedans = FALSE;
        }
    }
    fwrite($fic,"</tbody></table>");
    fclose($fic);
    if ($trouve != TRUE) {
        echo "je n'ai pas trouvé";
    }
?>